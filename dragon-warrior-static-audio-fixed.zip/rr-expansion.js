// RR interiors 8–10. World coordinates remain identical to the existing game.
const RR_EXP_RULES={gunnerHp:340,bomberHp:320,sergeantAtk:22,heliHp:650,heliAtk:26,blueHp:1600,blueAtk:32,taoHp:2000,taoAtk:36};
const rrSergeants=[{x:700,kind:'gunner',lo:460,hi:1080},{x:1000,kind:'bomber',lo:850,hi:1120},{x:1570,kind:'gunner',lo:1390,hi:1760},{x:1860,kind:'bomber',lo:1700,hi:2010}].map((d,i)=>({...d,spawn:d.x,id:i,size:d.kind==='gunner'?140:133,hp:d.kind==='gunner'?340:320,maxHp:d.kind==='gunner'?340:320,dir:-1,state:'idle',clock:0,cooldown:1+i*.4,walkDistance:0,hitTime:0}));
const rrHeli={kind:'heli',x:850,spawn:850,size:245,hp:650,maxHp:650,foot:245,dir:-1,state:'pursue',clock:0,cooldown:2,hitTime:0};
const rrBlue={kind:'blue',x:1550,spawn:1550,size:150,hp:1600,maxHp:1600,atk:32,dir:-1,state:'idle',clock:0,cooldown:1,special:0,combo:0,walkDistance:0,hitTime:0,engaged:false};
const rrTao={kind:'tao',x:1620,spawn:1620,size:145,hp:2000,maxHp:2000,atk:36,dir:-1,state:'idle',clock:0,cooldown:1,special:0,combo:0,walkDistance:0,hitTime:0};
const rrExpShots=[],rrExpBombs=[],rrAfterimages=[];
const rrWarehouseCrates=[];
for(const x of [260,1190,2070,2520]){rrWarehouseCrates.push({x,y:0,w:58,h:58},{x:x+58,y:0,w:58,h:58},{x:x+29,y:58,w:58,h:58});}
// 64-unit openings leave room to drop beside each stack; upper routes stay jump-reachable.
const rrCatwalks=[{a:440,b:1126,h:180},{a:1370,b:2006,h:180},{a:2250,b:2456,h:180}];
let rrRotorAudio=null,rrExpHud=null;
function rrLocal(id,en){return GameLanguage.locale==='id'?id:en;}
function loadExpansionMedia(){
 for(const [key,url] of Object.entries(RR_EXP_MEDIA.images)){if(media[key])continue;const im=gameImage();media[key]=im;im.src=url;}
 if(!rrRotorAudio&&RR_EXP_MEDIA.sounds.rotor){rrRotorAudio=new Audio(RR_EXP_MEDIA.sounds.rotor);rrRotorAudio.loop=true;rrRotorAudio.volume=.11;}
 if(!rrExpHud){rrExpHud=document.createElement('div');rrExpHud.id='rr-boss-hud';rrExpHud.hidden=true;rrExpHud.innerHTML='<strong></strong><div class="rr-boss-track"><i></i></div><span></span>';world.append(rrExpHud);}
}
function syncExpansionAudio(){if(!rrRotorAudio)return;const on=audioStarted&&!musicMuted&&!document.hidden&&mode==='gameplay'&&!travel&&area===8&&rrHeli.hp>0;if(on&&rrRotorAudio.paused)rrRotorAudio.play().catch(()=>{});if(!on&&!rrRotorAudio.paused)rrRotorAudio.pause();}
function clearExpansionHazards(){rrExpShots.length=0;rrExpBombs.length=0;rrAfterimages.length=0;p.stun=0;p.knockbackTime=0;p.knockbackVx=0;rrBlue.punishment=false;}
function resetExpansionArea(){
 clearExpansionHazards();if(area<8||area>10){if(rrExpHud)rrExpHud.hidden=true;return;}
 for(const d of rrSergeants)Object.assign(d,{x:d.spawn,hp:d.maxHp,dir:-1,state:'idle',clock:0,cooldown:1.5,hitTime:0,walkDistance:0,deathTime:0,deathY:0,deathBounces:0,rewarded:false,aiState:'patrol'});
 Object.assign(rrHeli,{x:850,foot:ground-325,hp:650,state:'pursue',clock:0,cooldown:2,deathTime:0,deathY:0,deathBounces:0,rewarded:false});
 for(const d of [rrBlue,rrTao]){const defeated=!!saved.rrBosses?.[d.kind];Object.assign(d,{x:d.spawn,hp:defeated?0:d.maxHp,dir:-1,state:'idle',clock:0,cooldown:1,special:0,combo:0,hitTime:0,walkDistance:0,deathTime:defeated?99:0,deathY:0,deathBounces:defeated?3:0,rewarded:defeated,engaged:false,punishment:false,hitDone:false});}
}
function expansionEnemies(){return area===8?[...rrSergeants,rrHeli]:area===9?[rrBlue]:area===10?[rrTao]:[];}
function expansionBody(d){const foot=d.kind==='heli'?d.foot:ground+HERO_VISUAL_DROP;const half=d.kind==='heli'?78:d.kind==='blue'?35:d.kind==='tao'?29:d.kind==='gunner'?32:27;return{left:d.x-half,right:d.x+half,top:foot-(d.kind==='heli'?85:d.size*.94),bottom:Math.min(d.kind==='heli'?Infinity:ground,foot-3)};}
function warehouseSolids(){return rrWarehouseCrates.map(q=>({left:q.x,right:q.x+q.w,top:ground-q.y-q.h,bottom:ground-q.y,crate:true}));}
function warehousePlatforms(){return rrCatwalks.map(q=>({left:q.a,right:q.b,top:ground-q.h,bottom:ground-q.h+46,bridge:true}));}
function warehouseSupport(x,foot=ground){let top=ground;for(const b of [...warehouseSolids(),...warehousePlatforms()])if(x>=b.left-10&&x<=b.right+10&&b.top>=foot-3)top=Math.min(top,b.top);return top;}
function moveWarehousePlayer(dt,axis){
 let left=dt;while(left>0){const step=Math.min(left,1/120);left-=step;const oldX=p.x,oldFoot=ground-p.y,was=p.grounded;const vx=was?axis*window.MABLE_PARAMS.moveSpeed*(p.attack>0||p.cast>0?.35:1):p.airVx;
 let nx=Math.max(28,Math.min(2722,oldX+vx*step));
 for(const b of warehouseSolids()){if(oldFoot>b.top+3&&oldFoot-96<b.bottom&&nx+14>b.left&&nx-14<b.right){if(oldX<=b.left)nx=Math.min(nx,b.left-14);else if(oldX>=b.right)nx=Math.max(nx,b.right+14);}}
 let foot=oldFoot;const support=warehouseSupport(nx,oldFoot);
 if(was&&Math.abs(oldFoot-support)<3){foot=support;p.vy=0;p.grounded=true;const dir=Math.sign(axis);if(Math.abs(axis)>.6&&nx!==oldX){p.runCharge=p.runDir===dir?Math.min(.5,p.runCharge+step):0;p.runDir=dir;}else p.runCharge=0;}
 else{if(was){p.grounded=false;p.airVx=vx;p.runCharge=0;}foot=oldFoot-p.vy*step;p.vy-=1400*step;
  if(p.vy<=0){let land=ground;for(const b of [...warehouseSolids(),...warehousePlatforms()])if(nx+12>b.left&&nx-12<b.right&&oldFoot<=b.top+3&&foot>=b.top)land=Math.min(land,b.top);if(foot>=land&&oldFoot<=land+3){foot=land;p.vy=0;p.grounded=true;p.airVx=0;}}
  if(p.vy>0)for(const b of warehouseSolids())if(nx+12>b.left&&nx-12<b.right&&oldFoot-96>=b.bottom&&foot-96<b.bottom){foot=b.bottom+96;p.vy=0;}
 }
 p.x=nx;p.y=ground-foot;p.safeX=nx;
 }
}
function expState(d,state){d.state=state;d.clock=0;d.hitDone=false;}
function expStep(d,target,speed,dt){const dx=target-d.x,step=Math.sign(dx)*Math.min(Math.abs(dx),speed*dt);d.x+=step;d.walkDistance=(d.walkDistance||0)+Math.abs(step);if(Math.abs(dx)>1)d.dir=Math.sign(dx);return Math.abs(step)>0;}
function expansionDamage(d,amount,dir){
 if(d.hp<=0)return;d.hp=Math.max(0,d.hp-amount);d.hitTime=.22;d.hitDir=dir;d.flash=.12;d.hits=(d.hits||0)+1;
 if(d.hp>0)return;
 d.deathTime=0;d.deathY=0;d.deathVy=d.kind==='heli'?170:340;d.deathVx=dir*130;d.deathBounces=0;d.deathBase=d.kind==='heli'?d.foot:ground+HERO_VISUAL_DROP;d.state='dead';
 if(!d.rewarded){d.rewarded=true;const boss=d.kind==='blue'||d.kind==='tao';const gold=boss?(d.kind==='blue'?180:240):d.kind==='heli'?80:30+Math.floor(Math.random()*16);saved.gold=Math.min(MAX_POWER,saved.gold+gold);earnPower(boss?500:d.kind==='heli'?200:125);if(boss){saved.rrBosses={...(saved.rrBosses||{}),[d.kind]:true};if(d.kind==='blue'){rrBlue.engaged=false;rrBlue.punishment=false;p.stun=0;p.hitTime=0;}commitStory();}}
}
function updateExpDeath(d,dt){d.deathTime+=dt;if(d.deathBounces>=3)return;let left=dt;while(left>0){const step=Math.min(left,1/120);left-=step;d.x=Math.max(45,Math.min(2705,d.x+d.deathVx*step));d.deathY+=d.deathVy*step;d.deathVy-=1050*step;const lowest=d.kind==='heli'?d.deathBase-ground:0;if(d.deathY<=lowest&&d.deathVy<0){d.deathY=lowest;d.deathBounces++;d.deathVy*=-.58;d.deathVx*=.63;}}}
function hitExpansionMelee(tx,ty,damage){let hit=false;for(const d of expansionEnemies()){if(d.hp<=0)continue;const b=expansionBody(d);if(tx<b.left-18||tx>b.right+18||ty<b.top-8||ty>b.bottom+8)continue;expansionDamage(d,damage,p.punchDir);projectileContacts.push({x:tx,y:ty,kind:'body',born:time,area});hit=true;}return hit;}
function expansionHitPlayer(amount,kind,dir=1,force=false){
 if(rescue||p.hp<=0||!force&&p.inv>0)return false;
 p.hp=Math.max(0,p.hp-Math.max(1,amount-playerStats().def));sfx('impact');p.attack=0;p.cast=0;p.punchQueued=false;fistFlash.active=false;
 if(p.hp<=0){beginDeath();return true;}
 p.stun=0;hurtPlayer();input.left=input.right=input.down=false;resetAnalog();
 if(kind==='upper'||kind==='punishUpper'||kind==='bomb'){p.knockbackTime=0;launchGrenadeKnockUp();p.airVx=dir*(kind==='punishUpper'?660:330);p.dir=-dir;}
 else{p.knockUp=false;p.knockbackTime=.16;p.knockbackVx=dir*180;p.airVx=p.grounded?0:dir*180;p.hitTime=.3;p.inv=.42;}
 return true;
}
function updateExpansionControl(dt){if(p.stun>0){p.stun=Math.max(0,p.stun-dt);p.hitTime=.3;p.move=false;}if(p.knockbackTime>0){p.knockbackTime=Math.max(0,p.knockbackTime-dt);p.hitTime=.3;}}
function expTargetFloor(x,foot){return area===8?warehouseSupport(x,foot):ground;}
function queueExpBomb(x,y,tx,ty,kind,damage,duration=0){
 const b={x,y,startX:x,startY:y,tx:Math.max(35,Math.min(2715,tx)),ty,kind,damage,age:0,blastAge:0,phase:'flight',duration,didHit:false};
 if(kind==='air'){b.vy=90;}else{b.duration=duration||.85+Math.min(.25,Math.abs(tx-x)/1500);b.vx=(b.tx-x)/b.duration;b.vy=(ty-y-.5*760*b.duration*b.duration)/b.duration;}
 rrExpBombs.push(b);
}
function updateExpBombs(dt){for(const b of rrExpBombs){if(b.phase==='blast'){b.blastAge+=dt;continue;}b.age+=dt;if(b.kind==='air'){b.vy+=720*dt;b.y+=b.vy*dt;}else{const t=Math.min(b.age,b.duration);b.x=b.startX+b.vx*t;b.y=b.startY+b.vy*t+.5*760*t*t;}
 if(b.kind==='air'?b.y>=b.ty:b.age>=b.duration){b.phase='blast';b.x=b.tx;b.y=b.ty;b.blastAge=0;sfx('grenadeBoom');const foot=ground-p.y+HERO_VISUAL_DROP,radius=115,height=90;if(Math.abs(p.x-b.x)<radius+18&&foot>b.y-height&&foot-96<b.y+12)expansionHitPlayer(b.damage,'bomb',p.x>=b.x?1:-1);}}
 for(let i=rrExpBombs.length-1;i>=0;i--)if(rrExpBombs[i].blastAge>(rrExpBombs[i].kind==='air'?.55:RABBIT_DEFENSE_MEDIA.blast.durationMs/1000))rrExpBombs.splice(i,1);
}
function updateSergeant(d,dt){
 if(d.hp<=0){updateExpDeath(d,dt);return;}d.clock+=dt;d.hitTime=Math.max(0,d.hitTime-dt);d.cooldown=Math.max(0,d.cooldown-dt);const dx=p.x-d.x,dist=Math.abs(dx);d.move=false;
 if(d.state==='shoot'){
  while(d.burst<5&&d.clock>=d.burst*.11){const m={x:d.x+d.dir*61,y:ground+HERO_VISUAL_DROP-83};rrExpShots.push({...m,dir:d.dir,life:2.1,vy:0,damage:22});d.burst++;sfx('blast');}
  if(d.clock>=.6){expState(d,'idle');d.cooldown=2;}return;
 }
 if(d.state==='aim'){if(d.clock>=1){for(const offset of [-105,0,105])queueExpBomb(d.x+d.dir*20,ground-85,d.targetX+offset,d.targetY,'triple',22);expState(d,'throw');d.cooldown=2.8;sfx('blast');}return;}
 if(d.state==='throw'){if(d.clock>.45)expState(d,'idle');return;}
 if(rescue||p.hp<=0)return;
 if(dist>560||p.x<d.lo-220||p.x>d.hi+220){d.hp=Math.min(d.maxHp,d.hp+d.maxHp*.05*dt);d.move=expStep(d,d.spawn,42,dt);return;}
 d.dir=dx>=0?1:-1;
 if(d.cooldown<=0){if(d.kind==='gunner'){d.burst=0;expState(d,'shoot');}else{d.targetX=p.x;d.targetY=expTargetFloor(p.x,ground-p.y);expState(d,'aim');}return;}
 if(dist>220)d.move=expStep(d,Math.max(d.lo,Math.min(d.hi,p.x)),48,dt);
}
function updateHelicopter(dt){const d=rrHeli;if(d.hp<=0){updateExpDeath(d,dt);return;}d.hitTime=Math.max(0,d.hitTime-dt);d.clock+=dt;d.cooldown=Math.max(0,d.cooldown-dt);d.foot=ground-325+Math.sin(time*2.1)*3;if(rescue||p.hp<=0)return;
 if(d.state==='lock'){if(d.clock>=1){queueExpBomb(d.x,d.foot-8,d.targetX,d.targetY,'air',26);sfx('blast');d.cooldown=2;expState(d,'pursue');}return;}
 const dx=p.x-d.x;if(Math.abs(dx)>3){d.dir=dx>0?1:-1;d.x+=Math.sign(dx)*Math.min(Math.abs(dx),210*dt);}if(Math.abs(p.x-d.x)<=6&&d.cooldown<=0){d.targetX=p.x;d.targetY=expTargetFloor(p.x,ground-p.y);d.x=p.x;expState(d,'lock');}
}
function startBlueDash(punishment=false){const d=rrBlue;d.punishment=punishment;d.dir=punishment?(p.x<1375?1:-1):(p.x>=d.x?1:-1);d.dashStart=d.x;d.dashEnd=Math.max(12,Math.min(2738,p.x-d.dir*55));d.dashDuration=.22;expState(d,'dash');}
function punishBlueEscape(){
 if(area!==9||rrBlue.hp<=0||!rrBlue.engaged||rescue||p.hp<=0)return false;
 if(!rrBlue.punishment){const d=rrBlue;d.punishment=true;d.escapeX=p.x;p.stun=2;p.hitTime=.3;p.knockUp=false;p.knockbackTime=0;p.airVx=0;p.vy=0;p.y=0;p.grounded=true;p.attack=0;p.cast=0;p.punchQueued=false;input.left=input.right=input.down=false;resetAnalog();expState(d,'punishwait');sfx('psychicZap');}
 return true;
}
function updateBlue(dt){const d=rrBlue;if(d.hp<=0){updateExpDeath(d,dt);return;}d.clock+=dt;d.cooldown=Math.max(0,d.cooldown-dt);d.special=Math.max(0,d.special-dt);d.hitTime=Math.max(0,d.hitTime-dt);d.move=false;if(rescue||p.hp<=0){d.engaged=false;return;}d.engaged=true;
 if((p.x<=35||p.x>=2715)&&!d.punishment&&!p.knockUp){punishBlueEscape();return;}
 if(d.state==='punishwait'){if(d.clock>=1.18)startBlueDash(true);return;}
 if(d.state==='dash'){const t=Math.min(1,d.clock/d.dashDuration);const before=d.x;d.x=d.dashStart+(d.dashEnd-d.dashStart)*t;const count=Math.max(1,Math.ceil(Math.abs(d.x-before)/60));for(let i=1;i<=count;i++)rrAfterimages.push({x:before+(d.x-before)*i/count,kind:d.kind,dir:d.dir,born:time});if(t>=1)expState(d,'charge');return;}
 if(d.state==='charge'){if(d.clock>=.5)expState(d,'upper');return;}
 if(d.state==='upper'){
  if(!d.hitDone&&d.clock>=.1){d.hitDone=true;const within=Math.abs(p.x-d.x)<115&&ground-p.y>ground-190;if(within||d.punishment)expansionHitPlayer(d.atk*2,d.punishment?'punishUpper':'upper',d.dir,d.punishment);d.special=10;d.punishment=false;}
  if(d.clock>.48){expState(d,'idle');d.cooldown=.75;}return;
 }
 if(['jab','rise','kick'].includes(d.state)){if(!d.hitDone&&d.clock>=.055){d.hitDone=true;if(Math.abs(p.x-d.x)<100&&(p.x-d.x)*d.dir>=-12&&p.y<145)expansionHitPlayer(d.atk*.5,'jab',d.dir);}if(d.clock>.26){expState(d,'idle');d.cooldown=.65;}return;}
 const dx=p.x-d.x,dist=Math.abs(dx);d.dir=dx>=0?1:-1;
 if(dist>220&&d.special<=0){startBlueDash();return;}
 if(dist<95&&d.cooldown<=0){expState(d,['jab','rise','kick'][d.combo++%3]);return;}
 if(dist>75)d.move=expStep(d,p.x-d.dir*72,115,dt);
}
function updateTao(dt){const d=rrTao;if(d.hp<=0){updateExpDeath(d,dt);return;}d.clock+=dt;d.cooldown=Math.max(0,d.cooldown-dt);d.special=Math.max(0,d.special-dt);d.hitTime=Math.max(0,d.hitTime-dt);d.move=false;if(rescue||p.hp<=0)return;
 if(d.state==='beamwind'){if(d.clock>=.55){expState(d,'beam');d.beamX=d.x+d.dir*46;d.beamY=ground+HERO_VISUAL_DROP-55;d.special=10;sfx('blast');}return;}
 if(d.state==='beam'){
  const duration=Math.max(.25,Math.min(.45,2*window.MABLE_PARAMS.jumpSpeed/1400-.15)),growth=Math.min(1,d.clock/.28);d.beamEnd=d.beamX+(d.dir>0?2750-d.beamX:-d.beamX)*growth;
  const foot=ground+HERO_VISUAL_DROP-p.y;if(!d.hitDone&&p.x+18>=Math.min(d.beamX,d.beamEnd)&&p.x-18<=Math.max(d.beamX,d.beamEnd)&&foot>d.beamY-9&&foot-100<d.beamY+9){d.hitDone=expansionHitPlayer(d.atk*1.5,'jab',d.dir);}
  if(d.clock>=duration){expState(d,'idle');d.cooldown=.7;}return;
 }
 if(['jab','rise','kick'].includes(d.state)){if(!d.hitDone&&d.clock>=.13){d.hitDone=true;if(Math.abs(p.x-d.x)<108&&(p.x-d.x)*d.dir>=-12&&p.y<145)expansionHitPlayer(d.atk*(d.state==='kick'?1.15:1),'jab',d.dir);}if(d.clock>.38){expState(d,'idle');d.cooldown=.45;}return;}
 const dx=p.x-d.x,dist=Math.abs(dx);d.dir=dx>=0?1:-1;
 if(dist>320&&d.special<=0){expState(d,'beamwind');return;}
 if(dist<95&&d.cooldown<=0){expState(d,['jab','rise','kick'][d.combo++%3]);return;}
 if(dist>76)d.move=expStep(d,p.x-d.dir*72,92,dt);
}
function updateExpansion(dt){
 if(area<8||area>10)return;updateExpansionControl(dt);
 if(area===8){for(const d of rrSergeants)updateSergeant(d,dt);updateHelicopter(dt);for(const b of rrExpShots)if(advanceHostileShot(b,dt,380,PROJECTILE_SHAPES.steel))expansionHitPlayer(b.damage,'jab',b.dir);for(let i=rrExpShots.length-1;i>=0;i--)if(rrExpShots[i].life<=0)rrExpShots.splice(i,1);updateExpBombs(dt);}
 else if(area===9)updateBlue(dt);else updateTao(dt);
 while(rrAfterimages.length&&(time-rrAfterimages[0].born>.28||rrAfterimages.length>50))rrAfterimages.shift();
}
function expSprite(d){
 const hurt=d.hp<=0||d.hitTime>0&&!['dash','charge','upper','beam','beamwind'].includes(d.state);let state;
 if(d.kind==='heli')state='hover';else if(hurt)state='hurt';else if(d.kind==='gunner')state=d.state==='shoot'?'shoot':d.move?'walk':'idle';else if(d.kind==='bomber')state=['aim','throw'].includes(d.state)?'throw':d.move?'walk':'idle';else state=['jab','rise','kick','charge','upper'].includes(d.state)?d.state:['beam','beamwind'].includes(d.state)?'beam':d.move?'walk':'idle';
 const pack=RR_EXP_MEDIA.actors[d.kind],g=pack.sprites[state],im=media[pack.keys[state]];let f=0;
 if(hurt&&d.kind!=='heli')f=Math.min(g.frames-1,g.recoilFrame??Math.floor(g.frames*.5));
 else if(d.kind==='bomber'&&state==='throw'){f=d.state==='aim'?Math.min(8,Math.floor(d.clock*9)):Math.min(g.frames-1,9+Math.floor(d.clock/.45*(g.frames-9)));}
 else if(state==='walk'){const duration=expDuration(g);f=rabbitFrame(g,(d.walkDistance||0)/100*duration);}
 else if(['idle','hover','shoot'].includes(state))f=rabbitFrame(g,time+(d.id||0)*.2);
 else{const duration=state==='charge'?.5:state==='upper'?.48:state==='throw'?.45:state==='beam'?.8:d.kind==='blue'?.26:.38;const ratio=Math.min(.999,d.clock/duration);f=Math.min(g.frames-1,Math.floor(ratio*g.frames));if(state==='charge'&&d.clock>.42)f=g.frames-1;if(state==='beam'&&d.state==='beam')f=Math.floor(g.frames*.65);}
 return{g,im,f,state};
}
function expDuration(g){return g.durationMs/1000||g.frameDurationsMs?.reduce((a,b)=>a+b,0)/1000||g.frames/g.fps;}
function drawExpActor(d,ghost){
 if(!ghost&&d.hp<=0&&d.deathTime>2.6)return;const {g,im,f}=expSprite(d);if(!im?.naturalWidth||!g)return;
 const geo=g.spriteGeometry||{pixelsPerUnit:g.frameHeight,pivot:{x:g.frameWidth/2,y:g.frameHeight}},z=d.size/geo.pixelsPerUnit;
 const base=d.kind==='heli'?(d.hp<=0?d.deathBase:d.foot):ground+HERO_VISUAL_DROP,foot=base-(d.hp<=0?d.deathY:0);
 if(!ghost&&d.kind!=='heli'){ctx.save();ctx.fillStyle='#243c3744';ctx.beginPath();ctx.ellipse(d.x,ground+7,28,5,0,0,7);ctx.fill();ctx.restore();}
 ctx.save();ctx.translate(d.x,foot);ctx.scale(d.dir,1);if(ghost)ctx.globalAlpha=ghost;else if(d.hp<=0)ctx.globalAlpha=monsterDeathAlpha(d.deathTime,2.6);
 ctx.drawImage(im,f%g.columns*g.frameWidth,Math.floor(f/g.columns)*g.frameHeight,g.frameWidth,g.frameHeight,-geo.pivot.x*z,-geo.pivot.y*z,g.frameWidth*z,g.frameHeight*z);ctx.restore();
 if(!ghost&&d.hp>0&&['gunner','bomber','heli'].includes(d.kind)){const y=foot-(d.kind==='heli'?100:d.size)-8;drawLobbyHealth(d,y,d.kind==='heli'?100:50);}
}
function drawExpBombs(){const bomb=media.exp_air_bomb,grenade=media.rabbit_grenade;
 for(const b of rrExpBombs){
  if(b.phase==='blast'){const g=RABBIT_DEFENSE_MEDIA.blast,im=media.rabbit_grenade_blast;if(!im?.naturalWidth)continue;const f=rabbitFrame(g,b.blastAge,false),normal=b.kind!=='air',w=normal?g.frameWidth*g.worldScale:230,h=normal?g.frameHeight*g.worldScale:110,duration=normal?g.durationMs/1000:.55;ctx.save();ctx.globalAlpha=Math.max(0,Math.min(1,(duration-b.blastAge)/.18));ctx.drawImage(im,f%g.columns*g.frameWidth,Math.floor(f/g.columns)*g.frameHeight,g.frameWidth,g.frameHeight,b.x-w/2,b.y-h*(normal?g.groundAnchor:1),w,h);ctx.restore();continue;}
  drawExpTarget(b.tx,b.ty,115,.65);
  const im=b.kind==='air'?bomb:grenade;if(im?.naturalWidth){const h=b.kind==='air'?34:23,w=h*im.naturalWidth/im.naturalHeight;ctx.save();ctx.translate(b.x,b.y);if(b.kind!=='air')ctx.rotate(b.age*6);ctx.drawImage(im,-w/2,-h/2,w,h);ctx.restore();}
 }
}
function drawExpTarget(x,y,r,alpha=1){ctx.save();ctx.globalAlpha=alpha;ctx.strokeStyle='#d44836';ctx.fillStyle='#f8ac4940';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,y-2,r,7,0,0,7);ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(x-6,y-7);ctx.lineTo(x+6,y+3);ctx.moveTo(x+6,y-7);ctx.lineTo(x-6,y+3);ctx.stroke();ctx.restore();}
function drawExpansion(){if(area<8||area>10)return;
 for(const a of rrAfterimages){const g=RR_EXP_MEDIA.actors.blue.sprites.idle,im=media.exp_blue_shadow;if(!im?.naturalWidth)continue;const z=rrBlue.size/g.spriteGeometry.pixelsPerUnit;ctx.save();ctx.globalAlpha=.36*(1-(time-a.born)/.28);ctx.translate(a.x,ground+HERO_VISUAL_DROP);ctx.scale(a.dir,1);ctx.drawImage(im,0,0,g.frameWidth,g.frameHeight,-g.spriteGeometry.pivot.x*z,-g.spriteGeometry.pivot.y*z,g.frameWidth*z,g.frameHeight*z);ctx.restore();}
 for(const d of expansionEnemies())drawExpActor(d);
 if(area===8){const d=rrHeli;if(d.hp>0&&d.state==='lock'){drawExpTarget(d.targetX,d.targetY,115,.6+.35*Math.sin(time*16));ctx.save();ctx.strokeStyle='#e7b04caa';ctx.setLineDash([4,9]);ctx.beginPath();ctx.moveTo(d.x,d.foot);ctx.lineTo(d.targetX,d.targetY);ctx.stroke();ctx.restore();}
  for(const s of rrSergeants)if(s.hp>0&&s.state==='aim')for(const off of [-105,0,105])drawExpTarget(s.targetX+off,s.targetY,115,.7);
  for(const b of rrExpShots){const im=media.rr_steel_bullet;if(im?.naturalWidth){ctx.save();ctx.translate(b.x,b.y);ctx.scale(b.dir,1);ctx.drawImage(im,-13,-3,26,6);ctx.restore();}}
  drawExpBombs();
 }
 if(area===9&&p.stun>0){const g=RR_EXP_MEDIA.shock,im=media.exp_shock;if(g&&im?.naturalWidth){const f=rabbitFrame(g,time);ctx.save();ctx.globalCompositeOperation=g.blendMode==='additive'?'lighter':'source-over';ctx.drawImage(im,f%g.columns*g.frameWidth,Math.floor(f/g.columns)*g.frameHeight,g.frameWidth,g.frameHeight,p.x-64,ground-p.y-120,128,145);ctx.restore();}}
 if(area===10&&rrTao.hp>0){const d=rrTao;if(d.state==='beamwind'){const x=d.x+d.dir*46,y=ground+HERO_VISUAL_DROP-55;ctx.save();ctx.strokeStyle='#e49037';ctx.setLineDash([10,12]);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(d.dir>0?2750:0,y);ctx.stroke();ctx.restore();}else if(d.state==='beam'){const im=media.exp_beam;if(im?.naturalWidth){const width=Math.abs(d.beamEnd-d.beamX);ctx.save();ctx.translate(d.beamX,d.beamY);ctx.scale(d.dir,1);ctx.drawImage(im,0,-15,width,30);ctx.restore();}}}
 // Reuse the authored player's strike glint, with the same additive ink/energy style.
 for(const d of expansionEnemies())if(d.hp>0&&['jab','rise','kick','upper'].includes(d.state)&&d.clock>.05&&d.clock<.24){const im=media.fist_glint_impact||glintImage,g=spriteData.fist_glint_impact;if(!im?.naturalWidth||!g)continue;const f=Math.min(g.frames-1,Math.floor((d.clock-.05)*60));ctx.save();ctx.translate(d.x+d.dir*52,ground+HERO_VISUAL_DROP-78);ctx.scale(d.dir,1);if(d.state==='upper'||d.state==='rise')ctx.rotate(-.55);ctx.globalCompositeOperation='lighter';ctx.drawImage(im,f%g.columns*g.frameWidth,Math.floor(f/g.columns)*g.frameHeight,g.frameWidth,g.frameHeight,-25,-22,88,44);ctx.restore();}
}
function drawExpansionMap(){
 const key=area===8?'exp_warehouse':area===9?'exp_hall':'exp_lab',im=media[key],floor=media.exp_floor;
 if(im?.naturalWidth){const height=area===10?350:ground,width=height*im.naturalWidth/im.naturalHeight;if(area===10)ctx.drawImage(im,300,35,600,100,0,0,W,ground-height+1);for(let i=Math.floor(cam/width);i<=Math.ceil((cam+W)/width);i++){ctx.save();ctx.translate(i*width-cam,ground-height);if(i%2){ctx.translate(width,0);ctx.scale(-1,1);}ctx.drawImage(im,0,0,width,height);ctx.restore();}}
 if(floor?.naturalWidth)for(let x=Math.floor(cam/520)*520;x<cam+W;x+=520)ctx.drawImage(floor,x-cam,ground,522,H-ground);
 if(area===8){const bridge=media.exp_bridge,crate=media.exp_crate;
  if(bridge?.naturalWidth)for(const q of rrCatwalks){const segments=Math.ceil((q.b-q.a)/300),width=(q.b-q.a)/segments;for(let i=0;i<segments;i++)ctx.drawImage(bridge,q.a+i*width-cam,ground-q.h,width+1,46);}
  if(crate?.naturalWidth)for(const q of rrWarehouseCrates)ctx.drawImage(crate,q.x-cam,ground-q.y-q.h,q.w,q.h+1);
 }
}
function expansionHint(){return area===8?rrLocal('Peti → jembatan. Lompat + J untuk memukul helikopter. Hindari tanda bom!','Crates → catwalk. Jump + J to hit the helicopter. Avoid bomb markers!'):area===9?rrLocal('General Blue mengunci arena. Hindari uppercut; kalahkan dia untuk membuka jalan.','General Blue locks the arena. Dodge his uppercut; defeat him to open the exits.'):rrLocal('Cyborg Tao: lompat saat garis bidik menyala. Kamu boleh mundur ke aula.','Cyborg Tao: jump when his aim line lights up. You may retreat to the hall.');}
function updateExpansionHud(){if(!rrExpHud)return;const d=area===9?rrBlue:area===10?rrTao:null;rrExpHud.hidden=!d||!['gameplay','profile'].includes(mode)||!!travel||!!rescue;if(rrExpHud.hidden)return;
 rrExpHud.querySelector('strong').textContent=d.kind==='blue'?'GENERAL BLUE':'CYBORG TAO PAI PAI';rrExpHud.querySelector('i').style.width=(Math.max(0,d.hp)/d.maxHp*100)+'%';
 const text=d.hp<=0?rrLocal('DIKALAHKAN · jalan terbuka','DEFEATED · route open'):d.punishment?rrLocal('DILARANG KABUR · setrum!','NO ESCAPE · electric stun!'):d.state==='charge'?rrLocal('UPPERCUT · hindari kepalannya!','UPPERCUT · dodge his fist!'):d.state==='beamwind'?rrLocal('LASER · siap melompat!','LASER · prepare to jump!'):d.kind==='blue'?rrLocal('Arena terkunci · kalahkan penjaganya','Arena locked · defeat the guardian'):rrLocal('Laboratorium · jalur mundur terbuka','Laboratory · retreat is possible');rrExpHud.querySelector('span').textContent=text;
 if(area===9&&d.hp>0&&!$('#destination').hidden)$('#destination-name').textContent=rrLocal('Arena terkunci','Arena locked');
}
