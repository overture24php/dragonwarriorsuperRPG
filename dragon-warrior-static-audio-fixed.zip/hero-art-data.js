// Hair-only repair of the original recoil; jump sizing fix retained.
Object.assign(spriteData.hero_jump,{spriteGeometry:{version:1,pixelsPerUnit:260,pivot:{x:86.5,y:320}}});
spriteData.hero_recoil_guard={"columns": 4, "rows": 4, "frameWidth": 194, "frameHeight": 287, "frames": 16, "fps": 20, "loop": false, "spriteGeometry": {"version": 1, "pixelsPerUnit": 263, "pivot": {"x": 97, "y": 287}}};
const repairedHeroRecoilBounds=[[2, 22, 192, 285], [2, 22, 192, 285], [10, 22, 181, 284], [34, 32, 170, 280], [54, 44, 166, 273], [48, 53, 155, 255], [51, 48, 158, 257], [53, 47, 158, 257], [46, 51, 158, 254], [46, 51, 158, 254], [46, 51, 158, 254], [46, 51, 158, 254], [46, 51, 158, 254], [46, 51, 158, 254], [46, 51, 158, 254], [46, 51, 158, 254]];
