// A failed Image needs a new request, not another listener for an event already fired.
const GameAssetLoader=(()=>{
 const sources=new WeakMap();let retrySerial=0;
 const aborted=()=>Object.assign(new Error('Loading cancelled'),{name:'AbortError'});
 function attempt(im,{signal,timeoutMs,prepare,restart}){return new Promise((resolve,reject)=>{
  let settled=false,decoding=false,timer;
  const finish=error=>{if(settled)return;settled=true;clearTimeout(timer);im.removeEventListener('load',loaded);im.removeEventListener('error',failed);signal?.removeEventListener('abort',cancel);error?reject(error):resolve(im);};
  const cancel=()=>finish(aborted()),failed=()=>finish(new Error('Image unavailable: '+sources.get(im)));
  const loaded=()=>{if(settled||decoding)return;decoding=true;Promise.resolve().then(()=>im.decode?im.decode():undefined).then(()=>{if(settled)return;if(!im.naturalWidth)throw Error('Empty image');prepare?.(im);finish();}).catch(finish);};
  if(signal?.aborted){cancel();return;}im.addEventListener('load',loaded);im.addEventListener('error',failed);signal?.addEventListener('abort',cancel,{once:true});timer=setTimeout(()=>finish(new Error('Image load timed out: '+sources.get(im))),timeoutMs);
  if(restart){try{const base=sources.get(im);let url=base;if(!/^(data:|blob:)/.test(base)){const u=new URL(base,document.baseURI);u.searchParams.set('_asset_retry',String(++retrySerial));url=u.href;}im.crossOrigin='anonymous';im.src=url;}catch(error){finish(error);return;}}
  if(im.complete){if(im.naturalWidth)loaded();else failed();}
 });}
 async function image(im,{signal,timeoutMs=45000,retries=2,prepare}={}){
  if(!im)throw Error('Missing image element');if(!sources.has(im))sources.set(im,im.getAttribute('src')||im.src||'');if(!sources.get(im))throw Error('Missing image URL');let last;
  for(let n=0;n<=retries;n++){if(signal?.aborted)throw aborted();try{return await attempt(im,{signal,timeoutMs,prepare,restart:n>0});}catch(error){if(error.name==='AbortError')throw error;last=error;}}
  throw last;
 }
 async function images(items,{signal,onProgress,...options}={}){const list=[...new Set(items)],failures=[];let cursor=0,done=0;await Promise.all(Array.from({length:Math.min(6,list.length)},async()=>{while(cursor<list.length){if(signal?.aborted)throw aborted();const im=list[cursor++];try{await image(im,{signal,...options});}catch(error){if(error.name==='AbortError')throw error;failures.push({src:sources.get(im),message:error.message});}onProgress?.(++done,list.length);}}));return failures;}
 return{image,images};
})();
