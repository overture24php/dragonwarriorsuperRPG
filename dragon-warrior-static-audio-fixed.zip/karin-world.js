// Peaceful city districts share one far-side pedestrian plane.
function isCapsuleCity(a){if(a===undefined){try{a=area;}catch{return false;}}return a===13||a===14||a===15;}
const CITY_BUILDINGS={13:[['capsule_corp',650,820],['police_station',2110,620]],14:[['space_station',830,560],['landed_spaceship',1950,260]],15:[['mr_satan_house',800,820],['restaurant',2180,520]]};
MONSTER_RULES.karinga={maxHp:320,patrol:100,leash:310,aggro:360,speed:65,stop:175};
const karingaGuards=[580,1130,1840,2390].map((spawn,i)=>({kind:'karinga',variant:i%2?'scout':'broad',spawn,x:spawn,maxHp:320,hp:320,dir:-1,phase:i*.6,patrolMin:spawn-100,patrolMax:spawn+100,leashMin:spawn-310,leashMax:Math.min(2720,spawn+310),cooldown:1.5,hitTime:0,deathTime:0}));
const karinSpears=[];
function loadKarinMedia(){for(const [key,url] of Object.entries(KARIN_MEDIA.images)){if(media[key])continue;const im=gameImage();media[key]=im;im.src=url;}}
function resetKarin(){karinSpears.length=0;for(const d of karingaGuards){Object.assign(d,{x:d.spawn,hp:d.maxHp,dir:-1,cooldown:1.5,attackTime:0,hitTime:0,phase:0,move:false,rewarded:false,deathTime:0,deathY:0,deathBounces:0});resetMonsterBrain(d);}}
function nearCityRoad(){return (area===11||area===13)&&Math.abs(p.x-1375)<85;}
function tryCityRoad(enter){if(mode!=='gameplay'||travel||p.knockUp||!p.grounded||p.y>1||!nearCityRoad()||enter!==(area===11))return false;const next=enter?13:11;travel={elapsed:0,dir:enter?2:0,next,swapped:false,walk:.35,depthDir:enter?-1:1,entryX:1375,entryDir:1};clearActions();p.move=true;$('#travel-name').textContent=areas[next].name;$('#destination').hidden=true;return true;}
function karinHint(){return area===11?rrLocal('Persimpangan damai · ↑ di tengah menuju kota · → menuju Hutan Karin','Peaceful crossroads · Up at the center: city · Right: Karin Forest'):isCapsuleCity()?rrLocal('Kota damai · ↓ di jalan tengah untuk kembali ke persimpangan','Peaceful city · Down at the central road to return to the crossroads'):rrLocal('Hindari tombak dengan melompat; dekati penjaga untuk bertarung.','Jump over spears; approach the guards to fight.');}
function karingaBody(d){return{left:d.x-(d.variant==='broad'?30:25),right:d.x+(d.variant==='broad'?30:25),top:ground-125,bottom:ground-3};}
function damageKaringa(d,amount,dir){if(d.hp<=0)return;d.hp=Math.max(0,d.hp-amount);monsterHitReaction(d,.35,dir);if(d.hp<=0){if(!d.rewarded){d.rewarded=true;saved.gold=Math.min(MAX_POWER,saved.gold+30+Math.floor(Math.random()*16));earnPower(125);}Object.assign(d,{move:false,attackTime:0,deathTime:0,deathY:0,deathVy:300,deathVx:dir*125,deathBounces:0});}}
function hitKaringaMelee(tx,ty,amount){let hit=false;for(const d of karingaGuards){const b=karingaBody(d);if(d.hp>0&&tx>=b.left-18&&tx<=b.right+18&&ty>=b.top&&ty<=b.bottom){damageKaringa(d,amount,p.punchDir);hit=true;}}return hit;}
function karingaHitPlayer(){if(rescue||p.hp<=0||p.inv>0)return;p.hp=Math.max(0,p.hp-Math.max(1,22-playerStats().def));p.inv=.72;sfx('hit');if(p.hp<=0)beginDeath();else hurtPlayer();}
function updateKarin(dt){if(area!==12)return;for(const d of karingaGuards){if(d.hp<=0){d.deathTime+=dt;updateMonsterDeathBounce(d,dt,d.leashMin,d.leashMax);if(d.deathTime>8){Object.assign(d,{hp:d.maxHp,x:d.spawn,rewarded:false,cooldown:1.5,hitTime:0});resetMonsterBrain(d);}continue;}
 const before=d.x;if(!updateMonsterBrain(d,dt)){d.walkDistance=(d.walkDistance||0)+Math.abs(d.x-before);continue;}
 if(d.attackTime>0){d.move=false;d.attackTime=Math.max(0,d.attackTime-dt);const elapsed=d.attackDuration-d.attackTime;if(!d.attackHit&&elapsed>=d.contactTime){d.attackHit=true;if(d.attackKind==='throw'){karinSpears.push({x:d.x+d.dir*58,y:ground-67,dir:d.dir,vy:0,life:2});sfx('hit');}else{const dx=(p.x-d.x)*d.dir,foot=ground+actorVisualDrop()-p.y;if(dx>=-15&&dx<125&&foot>ground-80&&foot-100<ground-50)karingaHitPlayer();sfx('hit');}}continue;}
 if(d.hitTime>0){d.move=false;continue;}const dx=p.x-d.x;d.dir=dx>=0?1:-1;const close=monsterPrefersClose(d,Math.abs(dx),105);if(d.cooldown<=0){d.attackKind=close?'thrust':'throw';d.attackDuration=close?.65:.85;d.contactTime=close?.25:.42;d.attackTime=d.attackDuration;d.attackHit=false;d.cooldown=close?1.25:2.1;d.move=false;}else if(Math.abs(dx)>180)monsterStep(d,p.x,65,dt);else d.move=false;d.walkDistance=(d.walkDistance||0)+Math.abs(d.x-before);
 }
 for(const b of karinSpears)if(advanceHostileShot(b,dt,340,{rx:34,ry:4}))karingaHitPlayer();for(let i=karinSpears.length-1;i>=0;i--)if(karinSpears[i].life<=0)karinSpears.splice(i,1);
}
function drawKarinEnemies(){if(area!==12)return;for(const d of karingaGuards){const dead=d.hp<=0;if(dead&&d.deathTime>2.3)continue;const state=dead||d.hitTime>0?'hurt':d.attackTime>0?d.attackKind:d.move?'walk':'idle',pack=KARIN_MEDIA.actors[d.variant],g=pack.sprites[state],im=media[pack.keys[state]];if(!g||!im?.naturalWidth)continue;const geo=state==='hurt'?{...g.spriteGeometry,pivot:{x:g.spriteGeometry.pivot.x,y:d.variant==='broad'?228:277}}:g.spriteGeometry,z=(d.variant==='broad'?140:132)/geo.pixelsPerUnit,duration=g.durationMs/1000||g.frames/g.fps;const f=dead||d.hitTime>0?Math.min(3,g.frames-1):rabbitFrame(g,d.attackTime>0?(d.attackDuration-d.attackTime)/d.attackDuration*duration:state==='walk'?guardWalkTime(d,g):time+d.phase,!(d.attackTime>0));ctx.save();ctx.fillStyle='#203c3440';ctx.beginPath();ctx.ellipse(d.x,ground+2,25,5,0,0,7);ctx.fill();ctx.translate(d.x,ground+HERO_VISUAL_DROP-(dead?d.deathY:0));if(dead)ctx.globalAlpha=monsterDeathAlpha(d.deathTime);ctx.scale(d.dir,1);ctx.drawImage(im,f%g.columns*g.frameWidth,Math.floor(f/g.columns)*g.frameHeight,g.frameWidth,g.frameHeight,-geo.pivot.x*z,-geo.pivot.y*z,g.frameWidth*z,g.frameHeight*z);ctx.restore();if(!dead)drawLobbyHealth(d,ground-148,52);}
 const im=media.karin_spear;if(im?.naturalWidth)for(const b of karinSpears){ctx.save();ctx.translate(b.x,b.y);ctx.scale(b.dir,1);ctx.drawImage(im,-34,-4,68,8);ctx.restore();}}
function karinProp(key,x,height,base=ground+5,flip=false){const im=media['karin_'+key];if(!im?.naturalWidth)return;const w=height*im.naturalWidth/im.naturalHeight;ctx.save();ctx.translate(x-cam,base);ctx.scale(flip?-1:1,1);ctx.drawImage(im,-w/2,-height,w,height);ctx.restore();}
function karinSign(x,text){ctx.save();ctx.font='bold 17px sans-serif';ctx.textAlign='center';ctx.lineWidth=5;ctx.strokeStyle='#f8edcc';ctx.fillStyle='#274a43';ctx.strokeText(text,x-cam,ground-15);ctx.fillText(text,x-cam,ground-15);ctx.restore();}
// The three additions share the established Earth art kit and terrain renderer.
function karinLayer(key,x,base,height,depth=1,flip=false,alpha=1){const im=media['karin_'+key];if(!im?.naturalWidth)return;const w=height*im.naturalWidth/im.naturalHeight,sx=x-cam*depth;if(sx+w/2<0||sx-w/2>W)return;ctx.save();ctx.globalAlpha=alpha;ctx.translate(sx,base);ctx.scale(flip?-1:1,1);ctx.drawImage(im,-w/2,-height,w,height);ctx.restore();}
function karinEarth(key,x,base,height,flip=false,alpha=1){mapStamp(ctx,key,x-cam,base,height,flip,alpha);}
function karinNorthPath(){
 const im=media.karin_forest_path;if(!im?.naturalWidth)return;
 // The branch descends below the high-ground walking surface, never into the sky.
 const x=1375-cam;ctx.drawImage(im,x-160,ground-10,320,H-ground+20);
}
function drawCapsulePanorama(){
 const im=media.karin_layer_city;if(!im?.naturalWidth)return;
 const height=area===11?470:540,width=height*im.naturalWidth/im.naturalHeight,depth=.22;
 // Continuous skyline spans every camera position; trees subsequently occlude its lower districts.
 const first=Math.floor(cam*depth/width)-1;
 for(let i=first;i*width-cam*depth<W;i++)karinLayer('layer_city',i*width+width/2,ground-(isCapsuleCity()?15:55),height,depth,false,.82);
}
// Ground is one continuous pedestrian plane; no alpha ledge below the actor's feet.
function citySurface(key,top,height,tileWidth,depth=1){
 const im=media['karin_'+key];if(!im?.naturalWidth)return;
 const offset=((cam*depth)%tileWidth+tileWidth)%tileWidth;
 for(let x=-offset;x<W;x+=tileWidth)ctx.drawImage(im,x,top,tileWidth+1,height);
}
// Exactly one vehicle per direction. A full off-map crossing is followed by a quiet gap.
const CITY_TRAFFIC_LANES=[
 {dir:1,speed:450,gap:2.8,delay:0,height:96,laneOffset:-178,hover:13},
 {dir:-1,speed:480,gap:3.4,delay:1.6,height:82,laneOffset:-105,hover:12}
];
function cityTrafficState(i,t=time){
 const lane=CITY_TRAFFIC_LANES[i];if(!lane)return null;
 const start=-240,end=2990,duration=(end-start)/lane.speed;
 const age=t-lane.delay;if(age<0)return null;
 const phase=age%(duration+lane.gap);if(phase>=duration)return null;
 return {...lane,x:lane.dir>0?start+phase*lane.speed:end-phase*lane.speed};
}
function drawCityTraffic(){
 const im=media.karin_traffic_car;if(!im?.naturalWidth)return;
 // Far lane travels left near the opposite curb; both bodies hover above their shadows.
 for(const i of [1,0]){
  const car=cityTrafficState(i);if(!car)continue;
  const h=car.height,w=h*im.naturalWidth/im.naturalHeight,x=car.x-cam,y=ground-car.laneOffset;
  if(x+w/2<0||x-w/2>W)continue;
  ctx.save();ctx.translate(x,y);ctx.fillStyle='#17333925';ctx.beginPath();ctx.ellipse(0,0,w*.34,2.5,0,0,Math.PI*2);ctx.fill();
  ctx.scale(car.dir,1);ctx.drawImage(im,-w/2,-h-car.hover+Math.sin(time*9+i)*1.2,w,h);ctx.restore();
 }
}
function drawCityBuilding(key,x,height){
 const im=media['karin_'+key];if(!im?.naturalWidth)return;
 const w=height*im.naturalWidth/im.naturalHeight,base=ground+4;
 ctx.save();ctx.fillStyle='#5c51422b';ctx.beginPath();ctx.ellipse(x-cam,base,w*.46,4,0,0,Math.PI*2);ctx.fill();ctx.restore();
 karinProp(key,x,height,base);
}
function drawKarinMap(){
 if(mapCache.dirty)bakeMapLayers();const city=isCapsuleCity(),cross=area===11;
 ctx.drawImage(mapCache.sky,0,0);
 repeatMapStrip(mapCache.far,cam*.16,ground-370,320);
 if(city||cross)drawCapsulePanorama();
 if(!city)repeatMapStrip(mapCache.mid,cam*.43,ground-295,320);
 if(city){
  // Skyline → far sidewalk/buildings → road/crossing/traffic → near curb.
  citySurface('sidewalk',ground-65,H-ground+65,1500);
  for(const [key,x,h] of CITY_BUILDINGS[area])drawCityBuilding(key,x,h);
  citySurface('boulevard',ground+38,180,1500);
  if(area===13){const zebra=media.karin_zebra_crossing;if(zebra?.naturalWidth)ctx.drawImage(zebra,1375-cam-105,ground+35,210,188);}
  drawCityTraffic();
  for(const x of [100,1250,1550,2650])karinEarth('rabbit_lamp',x,ground+8,145);
  if(area===13)karinProp('city_wayfinder',1490,138,ground+7);
 }else{
  if(cross){
   for(const [x,h] of [[60,365],[420,320],[820,390],[1930,375],[2300,330],[2690,400]])karinEarth('tree',x,ground+3,h,x%3===0);
   for(const [x,h] of [[240,88],[710,65],[2030,75],[2510,95]])karinEarth('rocks',x,ground+3,h,x%3===0);
  }else{
   for(const [x,h] of [[60,400],[290,345],[670,385],[1060,365],[1840,390],[2250,365],[2730,420]])karinEarth('tree',x,ground+3,h,x%3===0);
   karinProp('tower_base',1450,1120,ground+24);
   for(const [x,h,flip] of [[440,180,false],[900,163,true],[2070,178,false],[2530,158,true]])karinProp('village_hut',x,h,ground+5,flip);
   for(const [x,h] of [[120,95],[1140,72],[1700,80],[2840,100]])karinEarth('rocks',x,ground+3,h,x%3===0);
  }
  for(let x=35;x<2800;x+=145){if(cross&&Math.abs(x-1375)<185||!cross&&Math.abs(x-1450)<140)continue;karinEarth('shrub',x,ground+4,37+(x%4)*6,x%3===0);}
  ctx.save();ctx.beginPath();ctx.rect(0,ground,W,H-ground);ctx.clip();for(let y=ground;y<H;y+=512)repeatMapStrip(mapCache.soil,cam,y,512);ctx.restore();repeatMapStrip(mapCache.surface,cam,ground-(mapCache.solidTop||10),86);
  if(cross){karinNorthPath();for(const [x,y,h] of [[1240,ground-4,42],[1518,ground-3,44]])karinEarth('shrub',x,y,h,x%2===0);}
  if(cross)karinProp('forest_wayfinder',1490,125,ground+5);
 }
}
function drawKarinForeground(){
 if(!isCapsuleCity())return;
 // Only the upper crowns are visible: the forest drops below the near curb.
 for(let x=-200,i=0;x<3100;x+=230,i++){
  if(area===13&&Math.abs(x-1375)<170)continue;
  karinEarth('tree',x,H+430+(i%3)*12,500,i%2===0);
 }
}
