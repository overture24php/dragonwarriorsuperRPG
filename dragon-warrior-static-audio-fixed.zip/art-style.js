// Approved visual contract: docs/art-direction.md. Change art, never combat stats, here.
const ART_STYLE=Object.freeze({name:'classic-colorful',ink:'#29464b',sky:'#90d8d0',soil:'#bf925b',grass:'#79b94e',farHaze:.18,rabbitSlim:160,rabbitHeavy:150});
