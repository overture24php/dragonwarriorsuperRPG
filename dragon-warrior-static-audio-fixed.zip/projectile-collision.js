// Swept projectile bounds: nearest terrain/body contact wins, including between frames.
const PROJECTILE_SHAPES={ki:{rx:23,ry:14},dino:{rx:19,ry:7},rabbit:{rx:12,ry:6},steel:{rx:13,ry:3}};
const projectileContacts=[];
function sweptBox(x0,y0,x1,y1,box,rx=0,ry=0){
 let entry=0,exit=1;
 for(const [start,delta,lo,hi] of [[x0,x1-x0,box.left-rx,box.right+rx],[y0,y1-y0,box.top-ry,box.bottom+ry]]){
  if(Math.abs(delta)<1e-9){if(start<lo||start>hi)return null;continue;}
  let a=(lo-start)/delta,b=(hi-start)/delta;if(a>b)[a,b]=[b,a];entry=Math.max(entry,a);exit=Math.min(exit,b);if(entry>exit)return null;
 }
 return entry>=0&&entry<=1?entry:null;
}
function projectileTerrainBoxes(){
 const zones=area===3?valleyPlatforms:area===4?BEAR_TERRAIN_ZONES:[{a:0,b:2750,h:0}];
 const boxes=zones.map(z=>({left:z.a,right:z.b,top:ground-z.h,bottom:ground+10000}));if(area===8)boxes.push(...warehouseSolids(),...warehousePlatforms());return boxes;
}
function projectileBody(d){
 if(area===12)return karingaBody(d);if(area>=8)return expansionBody(d);const floor=floorAt(d.x);let half,height,foot;
 if(area===7)return lobbyTargetBounds(d);
 if(area===3){half=38;height=90;foot=floor+3-(d.slamY||0);}
 else if(area===4){half=36;height=120;foot=floor+HERO_VISUAL_DROP;}
 else if(area===5){half=d.variant==='heavy'?36:27;height=rabbitSize(d)*.82;foot=floor+3+RABBIT_MOB_ANCHOR_DROP;}
 else if(area===6){half=35;height=RR_RULES.size;foot=floor+HERO_VISUAL_DROP;}
 else{half=30;height=105;foot=floor+HERO_VISUAL_DROP;}
 return {left:d.x-half,right:d.x+half,top:foot-height,bottom:Math.min(floor,foot-3)};
}
function projectileTargets(){return area===12?karingaGuards:area>=8?expansionEnemies():area===2?trainingDummies:area===3?valleyDinos:area===4?bearThieves:area===5?rabbitMobs:area===6?redRibbonRobots:area===7?[...lobbyGuards,lobbyTank]:[];}
function firstProjectileContact(x0,y0,x1,y1,shape,targets){
 let hit=null,nearest=Infinity;
 // Terrain wins ties; solid cliffs cannot be shot through to a body behind them.
 for(const box of projectileTerrainBoxes()){const t=sweptBox(x0,y0,x1,y1,box,shape.rx,shape.ry);if(t!==null&&t<nearest){nearest=t;hit={kind:'terrain',box,t};}}
 for(const {target,box} of targets){const t=sweptBox(x0,y0,x1,y1,box,shape.rx,shape.ry);if(t!==null&&t<nearest){nearest=t;hit={kind:'body',target,box,t};}}
 if(hit){hit.x=x0+(x1-x0)*hit.t;hit.y=y0+(y1-y0)*hit.t;}
 return hit;
}
function stopProjectile(b,hit){
 b.x=hit.x;b.y=hit.y;b.life=0;
 // Place contact feedback on the struck surface rather than behind the projectile.
 const x=Math.max(hit.box.left,Math.min(hit.box.right,hit.x)),y=Math.max(hit.box.top,Math.min(hit.box.bottom,hit.y));
 projectileContacts.push({x,y,kind:hit.kind,born:time,area});if(projectileContacts.length>32)projectileContacts.shift();
}
function advanceHostileShot(b,dt,speed,shape){
 if(b.life<=0)return false;const step=Math.min(dt,b.life),x0=b.x,y0=b.y,x1=x0+b.dir*speed*step,y1=y0; // Gun/mouth axis stays horizontal.
 const foot=floorAt(p.x)+actorVisualDrop()-p.y,targets=!rescue&&p.hp>0?[{target:p,box:{left:p.x-19,right:p.x+19,top:foot-100,bottom:foot-5}}]:[];
 const hit=firstProjectileContact(x0,y0,x1,y1,shape,targets);b.life-=dt;b.vy=0;
 if(hit){stopProjectile(b,hit);return hit.kind==='body';}
 b.x=x1;b.y=y1;if(b.x<-30||b.x>2780)b.life=0;return false;
}
function drawProjectileContacts(){
 for(let i=projectileContacts.length-1;i>=0;i--){const h=projectileContacts[i],age=time-h.born;if(age>.22||h.area!==area){projectileContacts.splice(i,1);continue;}
  ctx.save();ctx.globalAlpha=1-age/.22;ctx.strokeStyle=h.kind==='terrain'?'#ffd68a':'#c6ffff';ctx.lineWidth=3;const r=5+age*40;ctx.beginPath();for(let k=0;k<6;k++){const a=k*Math.PI/3;ctx.moveTo(h.x+Math.cos(a)*r*.5,h.y+Math.sin(a)*r*.5);ctx.lineTo(h.x+Math.cos(a)*r,h.y+Math.sin(a)*r);}ctx.stroke();ctx.restore();
 }
}
