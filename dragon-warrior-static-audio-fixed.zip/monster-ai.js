// Per-enemy home territories and close-range Rabbit defense.
const MONSTER_RULES={dino:{maxHp:225,patrol:110,leash:300,aggro:340,speed:48,stop:205},bear:{maxHp:280,patrol:90,leash:260,aggro:280,speed:72,stop:76},rabbit:{maxHp:210,patrol:120,leash:330,aggro:340,speed:58,stop:150}};
const RABBIT_DEFENSE={bulletDamage:18,grenadeMultiplier:1.2,trigger:105,radius:115,bounces:3,gravity:850,restitution:.72,cooldown:3.2};
const rabbitGrenades=[];
function configureMonsterTerritories(){
 for(const [kind,list] of [['dino',valleyDinos],['bear',bearThieves],['rabbit',rabbitMobs],['robot',redRibbonRobots],['private',lobbyGuards]]){
  const rule=MONSTER_RULES[kind];
  for(const d of list){
   let lo=30,hi=2720;
   if(kind==='bear'){lo=BEAR_PATROL.a;hi=BEAR_PATROL.b;}
   if(kind==='dino'){
    const groups=[[30,820],[920,1570],[1700,2720]],group=groups.find(v=>d.spawn>=v[0]&&d.spawn<=v[1]);[lo,hi]=group;
    lo+=8;hi-=8;
   }
   const neighbors=list.filter(e=>e!==d&&e.spawn>=lo&&e.spawn<=hi);
   const left=Math.max(lo,...neighbors.filter(e=>e.spawn<d.spawn).map(e=>(d.spawn+e.spawn)/2+12));
   const right=Math.min(hi,...neighbors.filter(e=>e.spawn>d.spawn).map(e=>(d.spawn+e.spawn)/2-12));
   Object.assign(d,{kind,maxHp:rule.maxHp,patrolMin:Math.max(left,d.spawn-rule.patrol),patrolMax:Math.min(right,d.spawn+rule.patrol),leashMin:Math.max(lo,d.spawn-rule.leash),leashMax:Math.min(hi,d.spawn+rule.leash)});resetMonsterBrain(d);
  }
 }
}
function resetMonsterBrain(d){d.staggerTime=0;d.poiseTime=0;d.nearAttack=false;d.aiLastHp=d.hp;d.launchPending=false;d.launchTime=0;d.slamState='';d.slamY=0;d.slamVy=0;d.slamClock=0;d.aiState='patrol';d.patrolDir=d.patrolDir||1;d.recovering=false;d.grenadeCooldown=0;d.attackHit=false;}
function startMonsterReturn(d){d.aiState='return';d.recovering=true;d.attackTime=0;d.attackHit=false;d.hitTime=0;d.cooldown=Math.max(d.cooldown,1);clearEnemyHitEffect(d);d.launchTime=0;d.launchPending=false;}
function monsterStep(d,target,speed,dt){
 const dx=target-d.x;if(Math.abs(dx)<.5){d.move=false;return true;}
 d.dir=Math.sign(dx);const nx=d.x+Math.sign(dx)*Math.min(Math.abs(dx),speed*dt);
 if(monsterCanTraverse(d.x,nx)){if(d.kind==='private')d.walkDistance=(d.walkDistance||0)+Math.abs(nx-d.x);d.x=nx;d.move=true;return Math.abs(target-nx)<.5;}
 d.move=false;return false;
}
// Return true only when combat owns this enemy for the current frame.
function monsterHitReaction(d,duration,dir){
 d.hitDir=dir;
 // Damage and impact effects still apply; committed attacks finish their windup.
 const committed=d.attackTime>0||!!d.slamState||d.launchTime>0;
 d.hitTime=d.poiseTime>0||committed?0:Math.max(0,Math.min(duration,.3-(d.staggerTime||0)));
}
function monsterPrefersClose(d,distance,threshold){
 if(distance<=threshold)d.nearAttack=true;
 else if(distance>threshold+20)d.nearAttack=false;
 return d.nearAttack;
}
// Ordinary gun/mouth projectiles follow the muzzle axis, never the player's height.
function monsterShotVelocity(){return 0;}
function updateMonsterBrain(d,dt){
 // Finish returning home before re-engaging. Once home, detect a nearby player
 // even without another hit: a projectile may have triggered retreat before
 // the player crossed back into the territory. Never wait passively for full HP.
 d.poiseTime=Math.max(0,(d.poiseTime||0)-dt);
 if(d.hitTime>0){d.staggerTime=(d.staggerTime||0)+dt;if(d.staggerTime>=.3-1e-6){d.poiseTime=1.2;d.staggerTime=0;d.cooldown=Math.min(d.cooldown,.15);}}
 else if(d.poiseTime<=0)d.staggerTime=Math.max(0,(d.staggerTime||0)-dt*.5);
 if(d.poiseTime>0)d.hitTime=0;
 const rule=MONSTER_RULES[d.kind];
 const attacked=Number.isFinite(d.aiLastHp)&&d.hp<d.aiLastHp;
 if(d.aiState==='recover'&&!rescue&&p.hp>0&&p.x>=d.leashMin&&p.x<=d.leashMax&&Math.abs(p.x-d.x)<=rule.aggro+(attacked?90:0)&&monsterCanTraverse(d.x,p.x)){
  d.aiState='chase';d.recovering=false;d.cooldown=Math.min(d.cooldown,.6);
 }
 const combat=stepMonsterBrain(d,dt);d.aiLastHp=d.hp;return combat;
}
function stepMonsterBrain(d,dt){
 const rule=MONSTER_RULES[d.kind];d.phase+=dt;d.cooldown-=dt;d.grenadeCooldown=Math.max(0,(d.grenadeCooldown||0)-dt);d.hitTime=Math.max(0,d.hitTime-dt);
 if(d.fxActive){d.fxTime+=dt;if(d.fxTime>=impactDuration())clearEnemyHitEffect(d);}
 const valid=!rescue&&p.hp>0&&p.x>=d.leashMin&&p.x<=d.leashMax&&Math.abs(p.x-d.x)<=rule.aggro+90&&monsterCanTraverse(d.x,p.x);
 if((d.aiState==='chase'||d.aiState==='patrol'&&d.hp<d.maxHp)&&!valid)startMonsterReturn(d);
 if(d.aiState==='return'||d.aiState==='recover'){
  d.hp=Math.min(d.maxHp,d.hp+d.maxHp*.05*dt);d.hitTime=0;d.attackTime=0;
  const home=monsterStep(d,d.spawn,rule.speed*1.25,dt);
  if(home){d.x=d.spawn;d.move=false;d.aiState='recover';if(d.hp>=d.maxHp){d.aiState='patrol';d.recovering=false;d.cooldown=Math.max(d.cooldown,.6);}}
  return false;
 }
 if(d.aiState==='patrol'){
  if(valid&&Math.abs(p.x-d.x)<=rule.aggro){d.aiState='chase';return true;}
  const target=d.patrolDir>0?d.patrolMax:d.patrolMin;if(monsterStep(d,target,rule.speed*.48,dt))d.patrolDir*=-1;
  return false;
 }
 return true;
}
function loadRabbitDefenseMedia(){
 const dust=gameImage();media.dino_landing_dust=dust;dust.src="assets/harmony/dino-landing-dust.webp";
 for(const [key,path] of Object.entries(RABBIT_DEFENSE_MEDIA.images)){if(media[key])continue;const im=gameImage();media[key]=im;im.src=path;}
}
function dropRabbitGrenade(d){
 if(d.grenadeCooldown>0||d.aiState!=='chase')return false;
 rabbitGrenades.push({owner:d,x:d.x,y:floorAt(d.x)+HERO_VISUAL_DROP-58,vy:0,age:0,bounces:0,angle:0,spin:2.4,exploded:false,blastAge:0,cancelled:false});
 d.grenadeCooldown=RABBIT_DEFENSE.cooldown;d.cooldown=RABBIT_DEFENSE.cooldown;d.move=false;return true;
}
function launchGrenadeKnockUp(){
 hurtPlayer();input.left=input.right=input.down=false;resetAnalog();
 p.knockUp=true;p.knockElapsed=0;p.grounded=false;p.vy=window.MABLE_PARAMS.jumpSpeed;p.airVx=(Math.random()<.5?-1:1)*330;p.dir=-Math.sign(p.airVx);p.hitTime=.3;
 p.inv=Math.max(p.inv,2*window.MABLE_PARAMS.jumpSpeed/1400+.2);
}
function updateRabbitGrenades(dt){
 if(area!==5&&area!==7)return;
 for(const g of rabbitGrenades){
  if(g.cancelled)continue;
  if(g.exploded){g.blastAge+=dt;continue;}
  g.age+=dt;
  // Small physics steps preserve the three visible rebounds across frame rates.
  const contactY=floorAt(g.x)+HERO_VISUAL_DROP-15;
  let landedAfterBounces=false,remaining=dt;
  while(remaining>0&&!landedAfterBounces){
   const step=Math.min(remaining,1/120);remaining-=step;
   g.vy+=RABBIT_DEFENSE.gravity*step;g.y+=g.vy*step;g.angle+=g.spin*step;
   if(g.y>=contactY&&g.vy>0){
    g.y=contactY;
    if(g.bounces<RABBIT_DEFENSE.bounces){g.bounces++;g.vy=-g.vy*RABBIT_DEFENSE.restitution;g.spin*=-.72;}
    else landedAfterBounces=true;
   }
  }
  if(!landedAfterBounces)continue;
  g.exploded=true;g.blastAge=0;g.y=floorAt(g.x)+HERO_VISUAL_DROP;
  sfx('grenadeBoom');
  const foot=floorAt(p.x)+actorVisualDrop()-p.y,dx=Math.max(0,Math.abs(p.x-g.x)-20),dy=Math.max(0,g.y-foot);
  if(!rescue&&p.hp>0&&!p.knockUp&&p.inv<=0&&Math.hypot(dx,dy)<=RABBIT_DEFENSE.radius){
   const damage=Math.max(1,RABBIT_DEFENSE.bulletDamage-playerStats().def)*RABBIT_DEFENSE.grenadeMultiplier;
   p.hp=Math.max(0,p.hp-damage);g.hitPlayer=true;g.damage=damage;
   if(p.hp<=0){beginDeath();continue;}launchGrenadeKnockUp();
  }
 }
 const duration=(RABBIT_DEFENSE_MEDIA.blast.durationMs||1000)/1000;
 for(let i=rabbitGrenades.length-1;i>=0;i--)if(rabbitGrenades[i].cancelled||rabbitGrenades[i].exploded&&rabbitGrenades[i].blastAge>=duration)rabbitGrenades.splice(i,1);
}
function drawRabbitGrenades(foreground=false){
 if(area!==5&&area!==7)return;
 for(const g of rabbitGrenades){
  if(g.cancelled||foreground===g.exploded)continue;
  if(!g.exploded){const im=media.rabbit_grenade;if(im?.naturalWidth){ctx.save();ctx.translate(g.x,g.y);ctx.rotate(g.angle);const h=30,w=h*im.naturalWidth/im.naturalHeight;ctx.drawImage(im,-w/2,-h/2,w,h);ctx.restore();}continue;}
  const im=media.rabbit_grenade_blast,m=RABBIT_DEFENSE_MEDIA.blast;if(!im?.naturalWidth)continue;
  let ms=g.blastAge*1000,f=0;const durations=m.frameDurationsMs;
  if(durations?.length){while(f<m.frames-1&&ms>=durations[f]){ms-=durations[f];f++;}}else f=Math.min(m.frames-1,Math.floor(g.blastAge*(m.fps||24)));
  const width=m.frameWidth*m.worldScale,height=m.frameHeight*m.worldScale,pv=m.pivot||{x:.5,y:.5};
  ctx.save();ctx.globalCompositeOperation=m.blendMode==='additive'?'lighter':'source-over';ctx.drawImage(im,f%m.columns*m.frameWidth,Math.floor(f/m.columns)*m.frameHeight,m.frameWidth,m.frameHeight,g.x-pv.x*width,g.y-height*m.groundAnchor,width,height);ctx.restore();
 }
}

const DINO_SLAM={trigger:115,radius:140,windup:.22,jumpSpeed:410,gravity:1100,cooldown:3.2,damageMultiplier:.2};
const dinoDust=[];
function startDinoSlam(d){d.slamState='windup';d.slamClock=0;d.slamY=0;d.slamVy=0;d.move=false;d.cooldown=DINO_SLAM.cooldown;}
function updateDinoSlam(d,dt,combat){
 d.move=false;d.slamClock+=dt;
 if(d.slamState==='windup'){
  if(!combat){d.slamState='';return;}
  if(d.slamClock<DINO_SLAM.windup)return;
  d.slamState='air';d.slamVy=DINO_SLAM.jumpSpeed;d.slamClock=0;return;
 }
 d.slamY+=d.slamVy*dt-.5*DINO_SLAM.gravity*dt*dt;d.slamVy-=DINO_SLAM.gravity*dt;
 if(d.slamY>0)return;
 d.slamY=0;d.slamState='';d.cooldown=DINO_SLAM.cooldown;
 dinoDust.push({x:d.x,y:floorAt(d.x)+3,age:0});sfx('hit');
 if(combat&&!rescue&&p.hp>0&&p.inv<=0&&!p.knockUp&&monsterCanTraverse(d.x,p.x)&&Math.abs(p.x-d.x)<=DINO_SLAM.radius&&Math.abs(floorAt(p.x)-p.y-floorAt(d.x))<65){
  const damage=Math.max(1,24*DINO_ATTACK_SCALE-playerStats().def)*DINO_SLAM.damageMultiplier;
  p.hp=Math.max(0,p.hp-damage);if(p.hp<=0)beginDeath();else launchGrenadeKnockUp();
 }
}
function updateDinoDust(dt){for(const f of dinoDust)f.age+=dt;for(let i=dinoDust.length-1;i>=0;i--)if(dinoDust[i].age>=.95)dinoDust.splice(i,1);}
function drawDinoDust(){
 if(area!==3)return;const im=media.dino_landing_dust;if(!im?.naturalWidth)return;
 for(const f of dinoDust){const t=f.age/.95,size=68+20*t;for(const side of [-1,1]){ctx.save();ctx.globalAlpha=Math.pow(1-t,1.5);ctx.translate(f.x+side*(25+50*t),f.y-7*t);ctx.scale(side,1);ctx.drawImage(im,-size*.32,-size*.7,size,size*.7);ctx.restore();}}
}

// Shared death presentation: three diminishing landings, then blink/fade before respawn.
function monsterDeathAlpha(t,duration=2.3){return (Math.floor(t/.12)%2?.2:1)*Math.max(0,Math.min(1,(duration-t)/.4));}
function updateMonsterDeathBounce(d,dt,lo=d.leashMin??30,hi=d.leashMax??2720){
 let remaining=dt;while(remaining>0&&d.deathBounces<3){const step=Math.min(remaining,1/120);remaining-=step;const before=floorAt(d.x);d.x=Math.max(lo,Math.min(hi,d.x+d.deathVx*step));d.deathY+=d.deathVy*step+floorAt(d.x)-before;d.deathVy-=1050*step;if(d.deathY<=0&&d.deathVy<0){d.deathY=0;d.deathBounces++;d.deathVy=d.deathBounces<3?-d.deathVy*.58:0;d.deathVx=d.deathBounces<3?d.deathVx*.63:0;}}
}
