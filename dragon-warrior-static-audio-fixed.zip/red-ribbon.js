// Outer forest: same home/leash rules, with delayed position-lock missiles.
MONSTER_RULES.robot={maxHp:320,patrol:105,leash:350,aggro:330,speed:52,stop:190};
const RR_RULES={attack:24,radius:115,ascend:1,lock:1,diveSpeed:420,cooldown:4.8,size:138};
const redRibbonRobots=[620,1230,1930,2460].map((spawn,i)=>({spawn,x:spawn,dir:-1,kind:'robot',hp:320,maxHp:320,phase:i*.6,cooldown:2+i*.5,hitTime:0,move:false,hits:0,fxActive:false,fxTime:0,rewarded:false,deathTime:0,launchTime:0}));
const rrRockets=[],rrSmoke=[];
const RR_LAUNCH={duration:1.05,release:.55};
function robotLaunchFrame(d){const g=RR_MEDIA.sprites.launch;return rabbitFrame(g,Math.max(0,RR_LAUNCH.duration-d.launchTime)/RR_LAUNCH.duration*(g.durationMs?g.durationMs/1000:g.frames/g.fps),false);}
function robotLaunchMuzzle(d){const g=RR_MEDIA.sprites.launch,z=RR_RULES.size/g.spriteGeometry.pixelsPerUnit,m=g.launchSocket;return{x:d.x+d.dir*(m.x-g.spriteGeometry.pivot.x)*z,y:floorAt(d.x)+HERO_VISUAL_DROP+(m.y-g.spriteGeometry.pivot.y)*z};}
function beginRobotLaunch(d){d.launchTime=RR_LAUNCH.duration;d.launchPending=true;d.move=false;d.cooldown=RR_RULES.cooldown;}
function resetRedRibbon(){rrRockets.length=0;rrSmoke.length=0;for(const d of redRibbonRobots){resetMonsterBrain(d);Object.assign(d,{x:d.spawn,hp:320,maxHp:320,cooldown:2,hitTime:0,launchTime:0,rewarded:false,deathTime:0,deathY:0,deathVy:0,deathVx:0,deathBounces:0,launchPending:false});}}
function loadRedRibbonMedia(){for(const [key,path] of Object.entries(RR_MEDIA.images)){if(media[key])continue;const im=gameImage();media[key]=im;im.src=path;}}
function defeatRobot(d,dir){if(d.rewarded)return;d.rewarded=true;d.hp=0;d.move=false;d.launchTime=0;d.launchPending=false;d.deathTime=0;d.deathY=0;d.deathVy=330;d.deathBounces=0;d.deathVx=dir*115;clearEnemyHitEffect(d);saved.gold=Math.min(MAX_POWER,saved.gold+31+Math.floor(Math.random()*10));earnPower(125);}
function fireRobotRocket(d){const muzzle=robotLaunchMuzzle(d),y=muzzle.y-24;rrRockets.push({owner:d,phase:'ascend',age:0,x:muzzle.x,y,startX:muzzle.x,startY:y,targetX:p.x,targetY:floorAt(p.x)+HERO_VISUAL_DROP,angle:0,smokeClock:0,blastAge:0,cancelled:false});d.launchPending=false;sfx('blast');}
function updateRedRibbon(dt){if(area!==6)return;for(const d of redRibbonRobots){
 if(d.hp<=0){d.deathTime+=dt;updateMonsterDeathBounce(d,dt);if(d.deathTime>=8){resetMonsterBrain(d);Object.assign(d,{x:d.spawn,hp:320,cooldown:2,rewarded:false,deathTime:0,deathY:0,deathVy:0,deathVx:0,deathBounces:0});}continue;}
 if(!updateMonsterBrain(d,dt))continue;
 if(d.launchTime>0){
  d.move=false;
  if(d.hitTime>0&&d.launchPending){d.launchTime=0;d.launchPending=false;d.cooldown=Math.min(d.cooldown,.6);continue;}
  d.launchTime=Math.max(0,d.launchTime-dt);
  if(d.launchPending&&RR_LAUNCH.duration-d.launchTime>=RR_LAUNCH.release)fireRobotRocket(d);
  continue;
 }
 const dx=p.x-d.x;d.dir=dx>=0?1:-1;
 if(d.hitTime>0){d.move=false;continue;}
 if(d.cooldown<=0){beginRobotLaunch(d);continue;}
 if(Math.abs(dx)>MONSTER_RULES.robot.stop)monsterStep(d,p.x,MONSTER_RULES.robot.speed,dt);else d.move=false;
 }
 updateRockets(dt);
}
function updateRockets(dt){
 for(const s of rrSmoke)s.age+=dt;for(let i=rrSmoke.length-1;i>=0;i--)if(rrSmoke[i].age>=.65)rrSmoke.splice(i,1);
 for(const r of rrRockets){if(r.cancelled)continue;if(r.phase==='blast'){r.blastAge+=dt;continue;}r.age+=dt;
 if(r.phase==='ascend'){
  const t=Math.min(1,r.age/RR_RULES.ascend),straight=.15;
  r.targetX=p.x;r.targetY=floorAt(p.x)+HERO_VISUAL_DROP;
  const oldX=r.x,oldY=r.y;
  if(t<=straight){r.x=r.startX;r.y=r.startY-54*t/straight;r.angle=0;}
  else{const u=(t-straight)/(1-straight),ease=u*u*(3-2*u);
   r.x=r.startX+(r.targetX-r.startX)*ease+Math.sin(u*Math.PI*6)*42*Math.sin(u*Math.PI);
   r.y=r.startY-54+(floorAt(p.x)-p.y-300-(r.startY-54))*ease;
   r.angle=Math.atan2(r.x-oldX,-(r.y-oldY));
  }
  if(t>=1){r.phase='lock';r.age=0;r.turnFrom=r.angle;}
 }else if(r.phase==='lock'){
  r.targetX=p.x;r.targetY=floorAt(p.x)+HERO_VISUAL_DROP;r.x=r.targetX;r.y=floorAt(p.x)-p.y-300;
  const t=Math.min(1,r.age/.3);r.angle=r.turnFrom+(Math.PI-r.turnFrom)*t;
  if(r.age>=RR_RULES.lock){r.phase='dive';r.age=0;r.angle=Math.PI;r.x=r.targetX;r.lockedX=r.targetX;r.lockedY=r.targetY;}
 }else if(r.phase==='dive'){
  r.x=r.lockedX;r.y+=RR_RULES.diveSpeed*dt;
  if(r.y>=r.lockedY){r.y=r.lockedY;r.phase='blast';r.blastAge=0;sfx('grenadeBoom');
   const dx=Math.max(0,Math.abs(p.x-r.x)-20),dy=Math.max(0,r.y-(floorAt(p.x)+actorVisualDrop()-p.y));
   if(!rescue&&p.hp>0&&p.inv<=0&&!p.knockUp&&Math.hypot(dx,dy)<=RR_RULES.radius){const damage=Math.max(1,RR_RULES.attack-playerStats().def);p.hp=Math.max(0,p.hp-damage);r.hitPlayer=true;r.damage=damage;p.inv=.75;if(p.hp<=0)beginDeath();else hurtPlayer();}
  }
 }
 r.smokeClock+=dt;if(r.phase!=='blast'&&r.smokeClock>=.05){r.smokeClock=0;rrSmoke.push({x:r.x-Math.sin(r.angle)*20,y:r.y+Math.cos(r.angle)*20,age:0});}
 }
 for(let i=rrRockets.length-1;i>=0;i--)if(rrRockets[i].cancelled||rrRockets[i].phase==='blast'&&rrRockets[i].blastAge>=RABBIT_DEFENSE_MEDIA.blast.durationMs/1000)rrRockets.splice(i,1);
}
function drawRobot(d){const dead=d.hp<=0;if(dead&&d.deathTime>=2.3)return;const state=dead?'idle':d.launchTime>0?'launch':d.move?'walk':'idle',key='rr_guard_'+state,im=media[key],g=RR_MEDIA.sprites[state];if(!g||!im?.naturalWidth)return;const f=dead?0:state==='launch'?robotLaunchFrame(d):rabbitFrame(g,time+d.phase,true),geo=g.spriteGeometry,z=RR_RULES.size/geo.pixelsPerUnit,pv=geo.pivot;ctx.save();ctx.translate(d.x,floorAt(d.x)+HERO_VISUAL_DROP);ctx.fillStyle='#203a3344';ctx.beginPath();ctx.ellipse(0,0,30,6,0,0,7);ctx.fill();ctx.translate(0,dead?-d.deathY:0);if(dead){ctx.globalAlpha=monsterDeathAlpha(d.deathTime);ctx.rotate(d.dir*Math.min(d.deathTime,.45)*.8);}else if(d.hitTime>0&&state!=='launch')ctx.rotate(-d.dir*.07);ctx.scale(d.dir,1);ctx.drawImage(im,f%g.columns*g.frameWidth,Math.floor(f/g.columns)*g.frameHeight,g.frameWidth,g.frameHeight,-pv.x*z,-pv.y*z,g.frameWidth*z,g.frameHeight*z);ctx.restore();if(!dead){ctx.fillStyle='#263c37';ctx.fillRect(d.x-29,floorAt(d.x)-145,58,7);ctx.fillStyle=d.recovering?'#67d986':'#e16c55';ctx.fillRect(d.x-28,floorAt(d.x)-144,56*d.hp/d.maxHp,5);}}
function drawRRBlast(r){const im=media.rabbit_grenade_blast,m=RABBIT_DEFENSE_MEDIA.blast;if(!im?.naturalWidth)return;let ms=r.blastAge*1000,f=0;while(f<m.frames-1&&ms>=m.frameDurationsMs[f]){ms-=m.frameDurationsMs[f];f++;}const w=m.frameWidth*m.worldScale,h=m.frameHeight*m.worldScale;ctx.drawImage(im,f%m.columns*m.frameWidth,Math.floor(f/m.columns)*m.frameHeight,m.frameWidth,m.frameHeight,r.x-w*.5,r.y-h*m.groundAnchor,w,h);}
function drawRedRibbon(){if(area!==6)return;for(const d of redRibbonRobots)drawRobot(d);
 const smoke=media.dino_landing_dust;for(const s of rrSmoke){if(!smoke?.naturalWidth)break;const t=s.age/.65,w=12+19*t;ctx.save();ctx.globalAlpha=.48*(1-t);ctx.drawImage(smoke,s.x-w/2,s.y-w*.35,w,w*.7);ctx.restore();}
 for(const r of rrRockets){if(r.cancelled)continue;if(r.phase==='blast'){drawRRBlast(r);continue;}
 if(r.phase==='lock'||r.phase==='dive'){ctx.save();ctx.translate(r.targetX,r.targetY-3);ctx.strokeStyle=r.phase==='dive'?'#e53c2c':'#ffb540';ctx.fillStyle='rgba(233,70,40,.12)';ctx.lineWidth=3;ctx.setLineDash([10,7]);ctx.beginPath();ctx.ellipse(0,0,RR_RULES.radius,10,0,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.setLineDash([]);ctx.beginPath();ctx.moveTo(-12,0);ctx.lineTo(12,0);ctx.moveTo(0,-7);ctx.lineTo(0,7);ctx.stroke();ctx.restore();}
 const im=media.rr_tracking_rocket;if(im?.naturalWidth){ctx.save();ctx.translate(r.x,r.y);ctx.rotate(r.angle);const h=48,w=h*im.naturalWidth/im.naturalHeight;ctx.drawImage(im,-w/2,-h/2,w,h);ctx.restore();}
 }
}
